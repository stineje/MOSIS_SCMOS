This software is being provided to you, the LICENSEE, by the Illinois
Institute of Technology (IIT) under the following license.  By
obtaining, using and/or copying this software, you agree that you have
read, understood, and will comply with these terms and conditions:  

Permission to use, copy, and modify this software and its documentation for
research and educational purposes only and without fee or royalty is hereby
granted, provided that you agree to comply with the following copyright
notice and statements, including the disclaimer, and that the same appear
on ALL copies of the software and documentation, including modifications
that you make for internal use or for distribution:

Copyright 1999-2004 by the Illinois Institute of Technology.
All rights reserved.

Please note that the MIPS Instruction Set Architecture (ISA) is the
intellectual property of MIPS, Inc.  This code and all its contents is only for
use for academic use and in no way for commercial use.

This software is provided "as is", and IIT makes no representations or
warranties, express or implied.  by way of example, but not limitation,
IIT makes no representations or warranties of merchantability or fitness
for any particular purpose or that the use of the licensed software or
documentation will not infringe any third party patents, copyrights,
trademarks or other rights.   


